## HTML And CSS Template 3

Demo

https://elzerowebschool.github.io/HTML_And_CSS_Template_Three/

Learn How To Create The Design

https://www.youtube.com/watch?v=lXVP3rDH9EU&list=PLDoPjvoNmBAxuCSp2_-9LurPqRVwketnc

### If You Know JavaScript

You Can Add This Add-ons To The Design

- JavaScript Countdown => https://youtu.be/eFsiOTJrrE8
- Animate Width On Scrolling => https://youtu.be/sbIoIKI9FOc
- Increase Numbers On Scrolling => https://youtu.be/PLsUdgLnzgQ
